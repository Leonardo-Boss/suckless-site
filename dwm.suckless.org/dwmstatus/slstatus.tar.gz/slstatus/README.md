# slstatus
A suckless status monitor for DWM written in pure C without any system() calls.

# information

- wifi percentage
- battery percentage
- cpu usage in percent
- cpu temperature
- ram usage in percent
- alsa volume level in percent
- date
- time

# configuration

Just edit config.h and recompile!
